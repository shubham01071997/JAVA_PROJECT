package com.flight_reservation_app.controller;

import org.springframework.stereotype.Controller;
@Controller
public class PassengerController {

}
