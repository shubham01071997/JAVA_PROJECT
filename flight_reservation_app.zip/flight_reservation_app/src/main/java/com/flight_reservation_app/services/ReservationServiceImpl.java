package com.flight_reservation_app.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flight_reservation_app.dto.ReservationRequest;
import com.flight_reservation_app.entity.Reservation;
import com.flight_reservation_app.entity.flight;
import com.flight_reservation_app.entity.passenger;
import com.flight_reservation_app.repository.FlightRepository;
import com.flight_reservation_app.repository.PassengerRposiory;
import com.flight_reservation_app.repository.ReservationRepository;
import com.flight_reservation_app.utilities.EmailUtil;
import com.flight_reservation_app.utilities.PDFGenerator;
@Service
public class ReservationServiceImpl implements ReservationService {
	@Autowired
	private PassengerRposiory passengerRepo;
	@Autowired
	private FlightRepository flightRepo;
	
	@Autowired
	PDFGenerator pdfgenerator;
	@Autowired
	private EmailUtil emailutil;
	
	@Autowired
	private ReservationRepository reservationRepo;
	
	private static String filePath="C:\\Users\\shubham\\Desktop\\javaproject\\detail";
	@Override
	public Reservation bookFlight(ReservationRequest request) {
		passenger passenger=new passenger();
		passenger.setFirst_name(request.getFirst_name());
		passenger.setLast_name(request.getLast_name());
		passenger.setMiddle_name(request.getMiddle_name());
		passenger.setEmail(request.getEmail());
		passenger.setPhone(request.getPhone());
		passengerRepo.save(passenger);
		
		long flightId=request.getId();
		Optional<flight> findById = flightRepo.findById(flightId);
		flight flight=findById.get();
		
		Reservation reservation=new Reservation();
		reservation.setFlight(flight);
		reservation.setPassenger(passenger);
		reservation.setChecked_in(false);
		reservation.setNumber_of_bags(0);
		
		reservationRepo.save(reservation);
	
		PDFGenerator pdf=new PDFGenerator();
		pdf.generatePDF(filePath+reservation.getId()+".pdf", request.getFirst_name(),request.getEmail(), request.getPhone(),flight.getOperating_airlines(),flight.getDate_of_departure(),flight.getDeparture_city(),flight.getArrival_city());
		emailutil.sendItinerary("gaikwadshubham835@gmail.com",filePath);
		return reservation;
	}

}
