package com.flight_reservation_app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.flight_reservation_app.entity.passenger;

public interface PassengerRposiory extends JpaRepository<passenger,Long> {

}
