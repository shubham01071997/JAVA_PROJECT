package com.flight_reservation_app.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.flight_reservation_app.entity.flight;

public interface FlightRepository extends JpaRepository<flight,Long> {
  
    @Query("from flight where departure_city=:departureCity and arrival_city=:arrivalCity and date_of_departure=:dateOfDeparture")
	List<flight> findFlights(@Param("departureCity") String from,@Param("arrivalCity") String to,@Param("dateOfDeparture") Date departureDate);

}
