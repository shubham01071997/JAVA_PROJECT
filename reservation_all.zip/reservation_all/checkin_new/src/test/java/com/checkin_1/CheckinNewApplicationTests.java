package com.checkin_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CheckinNewApplicationTests {

	@Test
	void contextLoads() {
	}

}
