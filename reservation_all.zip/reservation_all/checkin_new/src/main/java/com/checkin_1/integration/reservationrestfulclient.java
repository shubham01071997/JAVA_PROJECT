package com.checkin_1.integration;

import org.springframework.web.bind.annotation.RequestBody;

//import org.springframework.web.bind.annotation.RequestBody;

import com.checkin_1.dto.reservation;
import com.checkin_1.dto.reservationupdtaerequest;

public interface reservationrestfulclient {
	public reservation findreservation(Long id);
	public reservation updatereservation(@RequestBody reservationupdtaerequest request);

}
