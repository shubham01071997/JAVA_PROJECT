package com.flight_app_self.controller;

import org.springframework.stereotype.Controller;

@Controller
public class passengercontroller {

}
