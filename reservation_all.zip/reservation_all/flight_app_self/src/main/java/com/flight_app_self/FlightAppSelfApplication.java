package com.flight_app_self;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightAppSelfApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlightAppSelfApplication.class, args);
	}

}
