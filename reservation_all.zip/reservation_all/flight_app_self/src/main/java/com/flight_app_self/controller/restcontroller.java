package com.flight_app_self.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flight_app_self.dto.reservationupdate;
import com.flight_app_self.entity.reservation;
import com.flight_app_self.repository.reservationrepo;

@RestController
public class restcontroller {
	
	@Autowired
	private reservationrepo resrepo;
	
	@RequestMapping("/reservation/{id}")
	public reservation findreservation(@PathVariable("id") Long id) {
		Optional<reservation> findById = resrepo.findById(id);
		reservation reservation = findById.get();
		return reservation;
	}
	
	@RequestMapping("/reservation")
	public reservation updatereservation(@RequestBody reservationupdate request) {
		Optional<reservation> findById = resrepo.findById(request.getId());
		reservation reservation = findById.get();
		reservation.setChecked_in(request.isChecked_in());
		reservation.setNumber_of_bags(request.getNumber_of_bags());
		return resrepo.save(reservation);
	}
	
	

}
