package com.flight_app_self.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.flight_app_self.entity.passenger;

public interface passengerrepo extends JpaRepository<passenger,Long> {

}
