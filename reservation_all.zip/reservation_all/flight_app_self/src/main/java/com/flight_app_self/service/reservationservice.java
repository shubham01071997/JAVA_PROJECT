package com.flight_app_self.service;

import com.flight_app_self.dto.reseervationdata;
import com.flight_app_self.entity.reservation;

public interface reservationservice {

   reservation bookflight(reseervationdata ress);

}
