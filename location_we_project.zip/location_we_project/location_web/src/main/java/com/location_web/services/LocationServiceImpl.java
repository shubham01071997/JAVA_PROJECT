package com.location_web.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.location_web.entity.location;
import com.location_web.repository.LocationRepository;

@Service
public class LocationServiceImpl implements LocationService{
	@Autowired
	private LocationRepository locationrepo;

	@Override
	public void saveLocation(location location) {
		// TODO Auto-generated method stub
		locationrepo.save(location);
		
	}

	@Override
	public List<location> getAllLocations() {
		// TODO Auto-generated method stub
		List<location>location=locationrepo.findAll();
		return location;
	}

	@Override
	public void deleteLocationById(Long id) {
		locationrepo.deleteById(id);
		
	}

	@Override
	public location findLocationById(Long id) {
		// TODO Auto-generated method stub
		Optional<location> findById = locationrepo.findById(id);
	    location location = findById.get();
		return location;
	}
	

}
