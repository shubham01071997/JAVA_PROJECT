package com.location_web.services;

import java.util.List;

import com.location_web.entity.location;

public interface LocationService {
	public void saveLocation(location location);
	public List<location> getAllLocations();
	public void deleteLocationById(Long id);
	public location findLocationById(Long id);

}
