package com.location_web.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.location_web.entity.location;
import com.location_web.repository.LocationRepository;

@RestController
public class LocationRestController1 {
	@Autowired
	private LocationRepository locationrepo;
	@RequestMapping("/location/{id}")
	public location getLocationById(@PathVariable long id) {
		Optional<location> findById = locationrepo.findById(id);
		location location=findById.get();
		return location;
		
	}

}
