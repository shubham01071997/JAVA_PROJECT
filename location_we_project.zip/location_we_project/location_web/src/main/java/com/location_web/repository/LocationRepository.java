package com.location_web.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.location_web.entity.location;

public interface LocationRepository extends JpaRepository<location,Long> {

}
