package com.location_web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.location_web.dto.saveLocationData;
import com.location_web.entity.location;
import com.location_web.services.LocationService;
import com.location_web.util.EmailUtil;

@Controller
public class LocationController {
	
	@Autowired
	private LocationService locationService;
	
	@Autowired
	private EmailUtil emailUtil;
	
	@RequestMapping("/showLocation")
	public String showlocationPage() {
		return "showLocation";
		
	}
	@RequestMapping("/saveLocation")
	public String saveLocation(@ModelAttribute("location") location location,ModelMap modelMap) {
		//System.out.println(location.getId());
		//System.out.println(location.getCode());
		//System.out.println(location.getName());
		//System.out.println(location.getType());
		locationService.saveLocation(location);
		emailUtil.sendEmail("gaikwadshubham835@gmail.com","welcome Email","Location is Saved");
		modelMap.addAttribute("msg","location saved");
		return "showLocation";
		
	}
//	@RequestMapping("/saveLocation")
//	public String saveLocation(@RequestParam("id") long id,@RequestParam("code") String code,@RequestParam("name") String name,@RequestParam("type") String type,ModelMap modelMap) {
//		//System.out.println(id);
//		//System.out.println(code);
//		//System.out.println(name);
//		//System.out.println(type);
//		location location=new location();
//		location.setId(id);
//		location.setName(name);
//		location.setCode(code);
//		location.setType(type);
//		locationService.saveLocation(location);
//		modelMap.addAttribute("msg","location saved!");
//		return "showLocation";
//	}
//	@RequestMapping("/saveLocation")
//	public String saveLocation(saveLocationData data,ModelMap modelMap) {
////		System.out.println(data.getId());
////		System.out.println(data.getCode());
////		System.out.println(data.getName());
////		System.out.println(data.getType());
//		location location=new location();
//		location.setId(data.getId());
//		location.setCode(data.getCode());
//		location.setName(data.getName());
//		location.setType(data.getType());
//		locationService.saveLocation(location);
//		modelMap.addAttribute("msg","location saved!");
//		return "showLocation";
//	}
	@RequestMapping("/getLocations")
	public String getLocations(ModelMap modelMap) {
		List<location>locations=locationService.getAllLocations();
		modelMap.addAttribute("locations",locations);
		return "allLocations";
		
	}
	@RequestMapping("/deleteLocation")
	public String deleteLocation(@RequestParam("id")long id,ModelMap modelMap){
		locationService.deleteLocationById(id);
		List<location>locations=locationService.getAllLocations();
		modelMap.addAttribute("locations",locations);
		return "allLocations";
	}
	@RequestMapping("/updateLocation")
	public String UpdateLocation(@RequestParam("id")Long id,ModelMap modelMap) {
		location location = locationService.findLocationById(id);
		modelMap.addAttribute("location",location);
		return "updateLocation";
	}
	@RequestMapping("/updateLocationData")
	public String updateLocationData(com.location_web.dto.updateLocationData locationData,ModelMap modelMap) {
		location location=new location();
		location.setId(locationData.getId());
		location.setCode(locationData.getCode());
		location.setName(locationData.getName());
		location.setType(locationData.getType());
		locationService.saveLocation(location);
		
		List<location>locations=locationService.getAllLocations();
		modelMap.addAttribute("locations",locations);
		return "allLocations";
		
		
	}
	
}
