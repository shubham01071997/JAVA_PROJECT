package com.search_location_web1.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.search_location_web1.dto.Location;

@Controller
public class searchLocationController {
	@RequestMapping("/searchlocation")
	public String showSearchLocation() {
		return "searchlocation";
	}
	@RequestMapping("/findLocation")
	public String findLocation(@RequestParam("id") long id,ModelMap modelMap) {
		RestClient restclient=new RestClient();
		Location location=restclient.getLocationBy(id);
		System.out.println(location.getId());
		System.out.println(location.getCode());
		System.out.println(location.getName());
		System.out.println(location.getType());
		modelMap.addAttribute("location",location);
		return "result";
	}
}
