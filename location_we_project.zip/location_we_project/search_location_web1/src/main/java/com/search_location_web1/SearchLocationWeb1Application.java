package com.search_location_web1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SearchLocationWeb1Application {

	public static void main(String[] args) {
		SpringApplication.run(SearchLocationWeb1Application.class, args);
	}

}
