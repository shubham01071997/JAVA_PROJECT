package com.mini_1.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mini_1.model.ClassDAO;
import com.mini_1.model.ClassDAOImpl;

@WebServlet("/verifylogin")
public class loginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public loginController() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		//System.out.println(email);
		//System.out.println(password);
		ClassDAO dao=new ClassDAOImpl();
		dao.connectDB();
		boolean rs=dao.verifylogin(email,password);
		if(rs==true){
			HttpSession session=request.getSession(true);
			session.setAttribute("email",email);
			RequestDispatcher rd=request.getRequestDispatcher("WEB-INF/views/NewReg.jsp");
			rd.forward(request,response);
		}else{
			request.setAttribute("login error","invalid username/password");
			RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
			rd.include(request,response);
		}
	
	}

}
