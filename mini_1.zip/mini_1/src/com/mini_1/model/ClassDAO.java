package com.mini_1.model;

import java.sql.ResultSet;

public interface ClassDAO {
	public void connectDB();
	public boolean verifylogin(String email, String password);
	public void saveReg(String name, String city, String email, String mobile);
	public ResultSet readAllReg();
	public void deleteRegiteration(String email);
	public void updateRegisteration(String email, String mobile);
}
