package com.checkin_1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.checkin_1.dto.reservation;
import com.checkin_1.dto.reservationupdtaerequest;
import com.checkin_1.integration.reservationrestfulclient;

@Controller
public class Restcontroller {
	
	@Autowired
	private reservationrestfulclient restt;
	@RequestMapping("/checkin")
	public String checkin() {
		return "checkin";
	}
	@RequestMapping("/processcheck")
	public String processcheckin(@RequestParam("id")Long id,ModelMap modelmap){
		reservation findreservation = restt.findreservation(id);
		modelmap.addAttribute("reservation",findreservation);
		return "displayres";
	}
	@RequestMapping("/process")
	public String processcheck(@RequestParam("id") Long id,@RequestParam("number_of_bags") int number_of_bags){
		reservationupdtaerequest request=new reservationupdtaerequest();
		request.setId(id);
		request.setNumber_of_bags(number_of_bags);
		request.setChecked_in(true);
		restt.updatereservation(request);
		System.out.println(id);
		System.out.println(number_of_bags);
		return "confirmreservation";	
	}
}
