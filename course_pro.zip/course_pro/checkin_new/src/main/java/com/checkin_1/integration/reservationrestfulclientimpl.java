package com.checkin_1.integration;

import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.checkin_1.dto.reservation;
import com.checkin_1.dto.reservationupdtaerequest;
@Component
public class reservationrestfulclientimpl implements reservationrestfulclient {

	@Override
	public reservation findreservation(Long id) {
		RestTemplate resttemp=new RestTemplate();
		reservation res = resttemp.getForObject("http://localhost:8080/flights/reservation/"+id,reservation.class);
		return res;
	}

	@Override
	public reservation updatereservation(reservationupdtaerequest request) {
		RestTemplate resttemp=new RestTemplate();
		resttemp.postForObject("http://localhost:8080/flights/reservation",request,reservation.class);
		return null;
	}
}
