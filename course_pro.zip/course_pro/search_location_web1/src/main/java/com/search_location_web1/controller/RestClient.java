package com.search_location_web1.controller;

import org.springframework.web.client.RestTemplate;

import com.search_location_web1.dto.Location;

public class RestClient {
	public Location getLocationBy(long id) {
		RestTemplate restTemplate=new RestTemplate();
		Location location=restTemplate.getForObject("http://localhost:8080/location/"+id,Location.class);
	
		return location;
	}

	

}
