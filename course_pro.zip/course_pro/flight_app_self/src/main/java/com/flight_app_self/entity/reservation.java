package com.flight_app_self.entity;

import javax.persistence.Entity;
import javax.persistence.OneToOne;

@Entity
public class reservation extends extra{
	private boolean checked_in;
	private int number_of_bags;
	@OneToOne
	private flight flight;
	@OneToOne
	private passenger passenger;
	public boolean isChecked_in() {
		return checked_in;
	}
	public void setChecked_in(boolean checked_in) {
		this.checked_in = checked_in;
	}
	public int getNumber_of_bags() {
		return number_of_bags;
	}
	public void setNumber_of_bags(int number_of_bags) {
		this.number_of_bags = number_of_bags;
	}
	public flight getFlight() {
		return flight;
	}
	public void setFlight(flight flight) {
		this.flight = flight;
	}
	public passenger getPassenger() {
		return passenger;
	}
	public void setPassenger(passenger passenger) {
		this.passenger = passenger;
	}
	

}
