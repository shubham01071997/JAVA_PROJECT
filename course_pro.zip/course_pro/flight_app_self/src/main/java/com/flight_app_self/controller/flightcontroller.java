package com.flight_app_self.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.flight_app_self.entity.flight;
import com.flight_app_self.repository.flightrepo;

@Controller
public class flightcontroller {
	
	@Autowired
	private flightrepo flightrep;
	
	@RequestMapping("/findflights")
	public String findflight(@RequestParam("from")String from,@RequestParam("to") String to, @RequestParam("departuredate") @DateTimeFormat(pattern = "MM-dd-yyyy") Date departuredate,ModelMap modelmap) {
		List<flight> findflights = flightrep.findflights(from,to,departuredate);   
		modelmap.addAttribute("findflights",findflights);
		return "display";
	}
	@RequestMapping("/showcompletereservation")
	public String showCompleteReservation(@RequestParam("flightId") Long flightId,ModelMap modelmap) {
		Optional<flight> findById = flightrep.findById(flightId);
		flight flight=findById.get(); 
		modelmap.addAttribute("flight",flight);
		return "showreservation";
	}
}
