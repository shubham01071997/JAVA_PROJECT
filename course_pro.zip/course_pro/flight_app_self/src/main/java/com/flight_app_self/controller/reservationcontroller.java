package com.flight_app_self.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.flight_app_self.dto.reseervationdata;
import com.flight_app_self.entity.reservation;
import com.flight_app_self.service.reservationservice;

@Controller
public class reservationcontroller {
	
	
	
	@Autowired
	private reservationservice resservice;
	
	@RequestMapping("/confirmreservation")
	public String confirmreservation(reseervationdata res,ModelMap modelmap) {
		reservation bookflight = resservice.bookflight(res);
		modelmap.addAttribute("bookFlightid",bookflight.getId());
		return "confirm";
	}
}
