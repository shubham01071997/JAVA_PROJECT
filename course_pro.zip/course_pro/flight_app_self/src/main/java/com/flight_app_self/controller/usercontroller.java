package com.flight_app_self.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.flight_app_self.entity.user;
import com.flight_app_self.repository.userrepo;

@Controller
public class usercontroller {
	@Autowired 
	private userrepo userrep;
	
	@RequestMapping("/showloginpage")
	public String showpage() {
		return "login/login";
	}
	
	@RequestMapping("/showreg")
	public String showreg() {
		return "login/showreg";
	}
	@RequestMapping("/savereg")
	public String savereg(@ModelAttribute("user") user user) {
		userrep.save(user);
		return "login/login";
	}
	
	@RequestMapping("verifylogin")
	public String logreg(@RequestParam("email")String email,@RequestParam("password") String password,ModelMap modelmap) {
		user user=userrep.findByEmail(email);
		if(user!=null) {
			if(user.getEmail().equals(email) && user.getPassword().equals(password)) {
				return "findflight";
			}else {
				modelmap.addAttribute("error", "Invalid username/password");
				return "login/login";
			}
		}else {
				modelmap.addAttribute("error", "Invalid username/password");
				return "login/login";
			}
		
	}
	

}
