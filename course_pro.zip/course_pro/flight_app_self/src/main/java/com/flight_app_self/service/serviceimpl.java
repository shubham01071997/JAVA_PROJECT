package com.flight_app_self.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flight_app_self.dto.reseervationdata;
import com.flight_app_self.entity.flight;
import com.flight_app_self.entity.passenger;
import com.flight_app_self.entity.reservation;
import com.flight_app_self.repository.flightrepo;
import com.flight_app_self.repository.passengerrepo;
import com.flight_app_self.repository.reservationrepo;
import com.flight_app_self.utillity.Emailutil;
import com.flight_app_self.utillity.pdfgenerator;
@Service
public class serviceimpl implements reservationservice {
	
	@Autowired
	private  passengerrepo passrepo;
	
	@Autowired
	private reservationrepo resrepo; 
	
	@Autowired
	private flightrepo flightrep;
	
	@Autowired
	pdfgenerator  pdfgenerator;
	
	@Autowired
	private Emailutil emailutil;
	
	private static String filepath="C:\\Users\\shubham\\Documents\\workspace-spring-tool-suite-4-4.7.2.RELEASE\\flight_app_self\\src\\tickets\\";

	@Override
	public reservation bookflight(reseervationdata ress) {
		passenger passenger=new passenger();
		passenger.setFirst_name(ress.getFirst_name());
		passenger.setLast_name(ress.getLast_name());
		passenger.setMiddle_name(ress.getMiddle_name());
		passenger.setEmail(ress.getEmail());
		passenger.setPhone(ress.getPhone());
		passrepo.save(passenger);
		
		long flightid=ress.getId();
		Optional<flight> findById = flightrep.findById(flightid);
		flight flight=findById.get();
		
		reservation reservation=new reservation();
		reservation.setFlight(flight);
		reservation.setPassenger(passenger);
		reservation.setChecked_in(false);
		reservation.setNumber_of_bags(0);
		resrepo.save(reservation);
		
		
		pdfgenerator pdf=new pdfgenerator();
		pdf.generatePDF(filepath+reservation.getId()+".pdf",ress.getFirst_name(),ress.getEmail(),ress.getPhone(),flight.getOperating_airlines(),flight.getDate_of_departure(),flight.getDeparture_city(), flight.getArrival_city());
		String filepath1 = filepath+reservation.getId()+".pdf";
		emailutil.sendItinerary("gaikwadshubham835@gmail.com",filepath1);
		return reservation;
	}
}
