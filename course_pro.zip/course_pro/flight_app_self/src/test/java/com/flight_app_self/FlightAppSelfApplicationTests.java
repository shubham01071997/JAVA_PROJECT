package com.flight_app_self;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightAppSelfApplicationTests {

	@Test
	void contextLoads() {
	}

}
