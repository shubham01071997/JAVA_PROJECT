package com.crud_demo.repositories;

import org.springframework.data.repository.CrudRepository;

import com.crud_demo.entities.student;

public interface studentRepository extends CrudRepository<student,Long> {

}
