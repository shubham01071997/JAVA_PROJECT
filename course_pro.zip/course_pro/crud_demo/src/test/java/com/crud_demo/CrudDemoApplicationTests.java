package com.crud_demo;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.crud_demo.entities.student;
import com.crud_demo.repositories.studentRepository;

@SpringBootTest
class CrudDemoApplicationTests {
	@Autowired
	private studentRepository studentrepo;

//	@Test
//	void saveRegistration() {
//		student s=new student();
//		s.setName("sanchita");
//		s.setCourse("software testing");
//		s.setFee(20000);
//		studentrepo.save(s);
//	}
//	@Test
//	void deleteRegistration() {
//		studentrepo.deleteById(2L);
//	}
//	@Test
//	void readRegisteration() {
//		Optional<student> findById = studentrepo.findById(1L);
//		student student=findById.get();
//		System.out.println(student.getId());
//		System.out.println(student.getName());
//		System.out.println(student.getCourse());
//		System.out.println(student.getFee());
//	}
	@Test
	void updateRegisteration() {
		Optional<student>findById=studentrepo.findById(1L);
		student s=findById.get();
		s.setCourse("java developer");
		studentrepo.save(s);
	}
}
