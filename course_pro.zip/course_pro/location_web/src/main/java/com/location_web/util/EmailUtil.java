package com.location_web.util;

public interface EmailUtil {
	public void sendEmail(String to,String sub,String body);
}
