package com.office_task;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OfficeTaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
