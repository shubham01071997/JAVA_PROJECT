package com.office_task.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class role {
	@Id
	private long id;
	private String rname;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getRname() {
		return rname;
	}
	public void setRname(String rname) {
		this.rname = rname;
	}
	
	

}
