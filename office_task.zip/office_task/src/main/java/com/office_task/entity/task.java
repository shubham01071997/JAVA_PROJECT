package com.office_task.entity;


import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import org.hibernate.annotations.CreationTimestamp;


@Entity
public class task {
	@Id
	private long token_id;
	@Column(unique=true)
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long user_id;
	private String name;
	private String email;
	private String role;
	private String designation;
	@CreationTimestamp
	private LocalDateTime date;
	private String is_active;
	public String getIs_active() {
		return is_active;
	}
	public void setIs_active(String is_active) {
		this.is_active = is_active;
	}
	public LocalDateTime getDate() {
		return date;
	}
	public void setDate(LocalDateTime date) {
		this.date = date;
	}
	public long getToken_id() {
		return token_id;
	}
	public void setToken_id(long token_id) {
		this.token_id = token_id;
	}
	public long getUser_id() {
		return user_id;
	}
	public void setUser_id(long user_id) {
		this.user_id = user_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}	
	@PrePersist
	public void preSave() {
	   if(is_active.isEmpty()){
	            is_active = "Y";
	    }
	}
}
