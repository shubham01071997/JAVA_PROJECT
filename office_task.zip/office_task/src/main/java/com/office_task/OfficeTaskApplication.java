package com.office_task;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OfficeTaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(OfficeTaskApplication.class, args);
	}

}
