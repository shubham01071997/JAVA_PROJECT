package com.office_task.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.office_task.entity.task;
import com.office_task.repository.taskrepository;

@RestController
@RequestMapping("/taskweb")
public class taskwebcontroller {
	@Autowired
	private taskrepository taskrepo;
	@GetMapping
	public List<task> gettaskweb(){
	        List<task> task=taskrepo.findAll();
	        return task;
	}
	@PostMapping
	public void insertdataweb(@RequestBody task task){
	      taskrepo.save(task);
	}

	@PutMapping
	public void updatetaskweb(@RequestBody task task){
	      taskrepo.save(task);      
	}

	@DeleteMapping("/deletetaskweb/{token_id}")
	public void deletetaskweb(@PathVariable("token_id") long token_id){
	     taskrepo.deleteById(token_id);
	}

}
