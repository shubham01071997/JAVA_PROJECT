package com.office_task.controller;


import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.office_task.dto.udpdatetask;
import com.office_task.entity.role;
import com.office_task.entity.task;
import com.office_task.services.taskservices;
import com.office_task.util.excelwritedb;


@Controller
public class taskcontroller {
	@Autowired
	private taskservices taskserv;
	
	@Autowired
	private excelwritedb exre;
	private static LocalDateTime now = LocalDateTime.now();  

	@RequestMapping("/task")
	public String gettask(ModelMap modelmap) {
		List<role>role=taskserv.getallrole();
		modelmap.addAttribute("role",role);
		
		List<task>tas=taskserv.getalldata();
		modelmap.addAttribute("tas",tas);
		return "employeedata";
	}
	@RequestMapping("/empdata")
	public String savetask(@ModelAttribute("task") task task,ModelMap modelmap) {
		taskserv.insert(task);
		List<role>role=taskserv.getallrole();
		modelmap.addAttribute("role",role);
		
		List<task>tas=taskserv.getalldata();
		modelmap.addAttribute("tas",tas);
		return "employeedata";
	}
	
	//all data place
	@RequestMapping("/deleteextra")
	public String deleteextra(@RequestParam("token_id") long token_id,ModelMap modelmap){
		
		taskserv.deletetask(token_id);
		
		List<role>role=taskserv.getallrole();
		modelmap.addAttribute("role",role);
		
		List<task>tas=taskserv.getalldata();
		modelmap.addAttribute("tas",tas);
		
		return "employeedata";
	}
	@RequestMapping("/updateextranew")
	public String updateextranew(@RequestParam("token_id") long token_id,ModelMap modelmap) {
		task task = taskserv.updatetask(token_id);
		modelmap.addAttribute("task",task);
		return "updateextranew";
	}	
	@RequestMapping("/uptask")
	public String uptask(udpdatetask uptask,ModelMap modelmap) {
		task task=new task();
		task.setToken_id(uptask.getToken_id());
		task.setUser_id(uptask.getUser_id());
		task.setName(uptask.getName());
		task.setEmail(uptask.getEmail());
		task.setRole(uptask.getRole());
		task.setDesignation(uptask.getDesignation());
		task.setDate(now);
		task.setIs_active(uptask.getIs_active());
		//task.setDate(uptask.getDate());
		taskserv.insert(task);
		
		List<role>role=taskserv.getallrole();
		modelmap.addAttribute("role",role);
		
		List<task>tas=taskserv.getalldata();
		modelmap.addAttribute("tas",tas);
		
		return "employeedata";
	}
	@RequestMapping("/download")
	public ResponseEntity<InputStreamResource> getFile() {
	    String filename = "task.xlsx";
	    InputStreamResource file = new InputStreamResource(taskserv.load());

	    return ResponseEntity.ok()
	        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
	        .contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
	        .body(file);
	  }
	//file upload
	
	@RequestMapping("/uploaddata")
	public String uploaddata(@RequestParam("excelfile") MultipartFile files,ModelMap modelmap) {
		System.out.println(files);
		
		exre.file_read(files);
		List<role>role=taskserv.getallrole();
		modelmap.addAttribute("role",role);
		
		List<task>tas=taskserv.getalldata();
		modelmap.addAttribute("tas",tas);
		
		return "employeedata";
	}
	@RequestMapping("/alldatatask")
	public String alldatatask(ModelMap modelmap) {
		List<task>tas=taskserv.getalldata();
		modelmap.addAttribute("tas",tas);
		return "alltasknew";
	}
	}  