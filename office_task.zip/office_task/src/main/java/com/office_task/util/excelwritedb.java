package com.office_task.util;




import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.office_task.entity.task;
import com.office_task.repository.taskrepository;


@Component
public class excelwritedb {
	@Autowired
	private taskrepository taskrepo;
	public void file_read(MultipartFile files){
	try {
       // FileInputStream file = new FileInputStream(new File("C:\\Users\\shubham\\Downloads\\task.xlsx"));
        XSSFWorkbook workbook = new XSSFWorkbook(files.getInputStream());
        XSSFSheet sheet1 = workbook.getSheetAt(0);
        XSSFSheet sheet2 = workbook.getSheetAt(1);
        Row row;
        for (int i = 1; i <= sheet1.getLastRowNum(); i++) {
            row = (Row) sheet1.getRow(i);
            long token_id=(long)row.getCell(0).getNumericCellValue();
            String name=row.getCell(1).getStringCellValue();
            String email=row.getCell(2).getStringCellValue();
            String role=row.getCell(3).getStringCellValue();
            String designation=row.getCell(4).getStringCellValue();
            String is_active=row.getCell(5).getStringCellValue();

            task et=new task();
            et.setToken_id(token_id);
            et.setName(name);
            et.setEmail(email);
            et.setRole(role);
            et.setDesignation(designation);
            et.setIs_active(is_active);
            taskrepo.save(et);
       }
        for (int i = 1; i <= sheet2.getLastRowNum(); i++) {
            row = (Row) sheet2.getRow(i);
            long token_id=(long)row.getCell(0).getNumericCellValue();
            String name=row.getCell(1).getStringCellValue();
            String email=row.getCell(2).getStringCellValue();
            String role=row.getCell(3).getStringCellValue();
            String designation=row.getCell(4).getStringCellValue();
            String is_active=row.getCell(5).getStringCellValue();
            
            task et=new task();
            et.setToken_id(token_id);
            et.setName(name);
            et.setEmail(email);
            et.setRole(role);
            et.setDesignation(designation);
            et.setIs_active(is_active);
            taskrepo.save(et);
       }
        workbook.close();
       System.out.println("save");
	}catch(Exception e) {
		e.printStackTrace();
	}
   }
}