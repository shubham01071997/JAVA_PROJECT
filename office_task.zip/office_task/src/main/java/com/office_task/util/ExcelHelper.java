package com.office_task.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;


import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;

import com.office_task.entity.task;
@Component
public class ExcelHelper {
	  public static String TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	  static String[] HEADERs = {"Token_id","User_Id","Name","Email","Role","Designation","Date","Is_Active"};
	  static String SHEET1 = "task1";
	  static String SHEET2 = "task2"; 
	  
	  public static ByteArrayInputStream tutorialsToExcel(List<task> task) {
		   
		    try (
		        Workbook workbook = new XSSFWorkbook(); 
		    	ByteArrayOutputStream out = new ByteArrayOutputStream();
		    	){
		      org.apache.poi.ss.usermodel.Sheet sheet1 = workbook.createSheet(SHEET1);
		      org.apache.poi.ss.usermodel.Sheet sheet2 = workbook.createSheet(SHEET2);
   
		      Row headerRow1 = sheet1.createRow(0);
		      Row headerRow2 = sheet2.createRow(0);
		      for (int col = 0; col < HEADERs.length; col++) {
		        Cell cell1 = headerRow1.createCell(col);
		        cell1.setCellValue(HEADERs[col]);
		        
		        Cell cell2 = headerRow2.createCell(col);
		        cell2.setCellValue(HEADERs[col]);
		      }
		      int a=1;
		      int b=1;
		      
		      for (task tas : task) {
		    	   // Row row1 = sheet1.createRow(a++);
		           // Row row2 = sheet2.createRow(b++);     
		            if(tas.getIs_active().equals("Y")) {
		            Row row1 = sheet1.createRow(a++);
                	row1.createCell(0).setCellValue(tas.getToken_id());
    		        row1.createCell(1).setCellValue(tas.getUser_id());
    		        row1.createCell(2).setCellValue(tas.getName());
    		        row1.createCell(3).setCellValue(tas.getEmail());
    		        row1.createCell(4).setCellValue(tas.getRole());
    		        row1.createCell(5).setCellValue(tas.getDesignation());
    		        row1.createCell(6).setCellValue(tas.getDate().toString());
    		        row1.createCell(7).setCellValue(tas.getIs_active());
		            }else {
		            Row row2 = sheet2.createRow(b++);
                	row2.createCell(0).setCellValue(tas.getToken_id());
    		        row2.createCell(1).setCellValue(tas.getUser_id());
    		        row2.createCell(2).setCellValue(tas.getName());
    		        row2.createCell(3).setCellValue(tas.getEmail());
    		        row2.createCell(4).setCellValue(tas.getRole());
    		        row2.createCell(5).setCellValue(tas.getDesignation());
    		        row2.createCell(6).setCellValue(tas.getDate().toString());
    		        row2.createCell(7).setCellValue(tas.getIs_active());
		            }
		    }	       
		      workbook.write(out);
		      return new ByteArrayInputStream(out.toByteArray());
		    } catch (IOException e) {
		      throw new RuntimeException("fail to import data to Excel file: " + e.getMessage());
		    }
	  }
}