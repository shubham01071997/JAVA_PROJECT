package com.office_task.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.office_task.entity.task;

public interface taskrepository extends JpaRepository<task,Long> {

}
