package com.office_task.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.office_task.entity.role;

public interface rolerepository extends JpaRepository<role,Long> {

}
