package com.office_task.dto;

import java.time.LocalDateTime;

import org.hibernate.annotations.UpdateTimestamp;

public class udpdatetask {
	private long token_id;
	private long user_id;
	private String name;
	private String email;
	private String role;
	private String designation;
	@UpdateTimestamp
	private LocalDateTime date;
	private String is_active;
	
	public String getIs_active() {
		return is_active;
	}
	public void setIs_active(String is_active) {
		this.is_active = is_active;
	}
	public LocalDateTime getDate() {
		return date;
	}
	public void setDate(LocalDateTime date) {
		this.date = date;
	}
	public long getToken_id() {
		return token_id;
	}
	public void setToken_id(long token_id) {
		this.token_id = token_id;
	}
	public long getUser_id() {
		return user_id;
	}
	public void setUser_id(long user_id) {
		this.user_id = user_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
}