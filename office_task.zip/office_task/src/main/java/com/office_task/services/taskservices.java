package com.office_task.services;

import java.io.ByteArrayInputStream;
import java.util.List;


import com.office_task.entity.role;
import com.office_task.entity.task;

public interface taskservices {
	public void insert(task task);
	public List<task> getalldata();
	public List<role> getallrole();
    public void deletetask(long token_id);
    public task updatetask(long token_id);
    
    public ByteArrayInputStream load();
}
