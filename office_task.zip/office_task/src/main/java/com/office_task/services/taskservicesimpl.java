package com.office_task.services;

import java.io.ByteArrayInputStream;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.office_task.entity.role;
import com.office_task.entity.task;
import com.office_task.repository.rolerepository;
import com.office_task.repository.taskrepository;
import com.office_task.util.ExcelHelper;
@Service
public class taskservicesimpl implements taskservices {
    @Autowired
	private taskrepository taskrepo;
    @Autowired
    private rolerepository rolerepo;
    @Override
	public void insert(task task) {
		taskrepo.save(task);
	}
	@Override
	public List<task> getalldata() {
		List<task>task=taskrepo.findAll();
		return task;
	}
 	@Override
	public void deletetask(long token_id) {
		taskrepo.deleteById(token_id);			
	}
	@Override
	public List<role> getallrole() {
		List<role>role=rolerepo.findAll();
		return role;
	}
	@Override
	public task updatetask(long token_id) {
		Optional<task> findById = taskrepo.findById(token_id);
		task task=findById.get();
		return task;
	}
	@Override
	public ByteArrayInputStream load() {
	    List<task> task = taskrepo.findAll();
	    ByteArrayInputStream in = ExcelHelper.tutorialsToExcel(task);
	    return in;
	  }
}